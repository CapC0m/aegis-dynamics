﻿using System.Collections.Generic;
using UnityEngine;
using KSP.UI.Screens;

namespace StokeEngine
{
    public class ModuleStokeRingEngine : ModuleEnginesFX, ITorqueProvider
    {
        // ---- Editor tweakables ----
        [KSPField(isPersistant = true, guiActiveEditor = true, guiName = "Thrust Chambers"),
         UI_FloatRange(minValue = 1f, maxValue = 24f, stepIncrement = 1f, scene = UI_Scene.Editor)]
        public float chamberCount = 6f;

        [KSPField(isPersistant = true, guiActive = true, guiActiveEditor = true,
                  guiName = "TVC Authority", guiFormat = "P0"),
         UI_FloatRange(minValue = 0f, maxValue = 1f, stepIncrement = 0.05f, scene = UI_Scene.All)]
        public float tvcAuthority = 0.5f;   // fraction of per-chamber throttle available for TVC

        [KSPField(isPersistant = true, guiActive = true, guiActiveEditor = true,
                  guiName = "Differential TVC"),
         UI_Toggle(scene = UI_Scene.All)]
        public bool tvcEnabled = true;

        // ---- Config tweakables ----
        [KSPField(isPersistant = true)] public float ringRadius = 0.6f;
        [KSPField(isPersistant = true)] public float thrustPerChamber = 60f;
        [KSPField] public float minThrottleFrac = 0.4f;    // minimum per-chamber throttle

        // ---- Internal state ----
        private const string CLONE_TX_NAME = "stokeChamberTransform";
        private int lastBuiltCount = -1;
        private float lastBuiltRadius = -1f;
        private List<float> chamberAngles = new List<float>();  // radians, one per chamber

        public override void OnStart(StartState state)
        {
            BuildRing();
            base.OnStart(state);
            RebindTransforms();
            RescaleThrust();
        }

        public void Update()
        {
            if (!HighLogic.LoadedSceneIsEditor) return;

            bool countChanged = (int)chamberCount != lastBuiltCount;
            bool radiusChanged = !Mathf.Approximately(ringRadius, lastBuiltRadius);

            if (!countChanged && !radiusChanged) return;

            Debug.Log($"[StokeEngine] Update triggered: count={chamberCount} (was {lastBuiltCount}), " +
                      $"radius={ringRadius} (was {lastBuiltRadius})");

            BuildRing();
            RebindTransforms();
            RescaleThrust();

            if (EditorLogic.fetch != null)
                GameEvents.onEditorShipModified.Fire(EditorLogic.fetch.ship);
        }

        // FixedUpdate = physics tick. Called before base-class thrust is applied,
        // so mutating thrustTransformMultipliers here affects this tick's thrust.
        public override void OnFixedUpdate()
        {
            base.OnFixedUpdate();

            if (!HighLogic.LoadedSceneIsFlight) return;
            if (vessel == null || !vessel.loaded) return;
            if (thrustTransforms == null || thrustTransformMultipliers == null) return;
            if (thrustTransforms.Count == 0) return;
            if (thrustTransforms.Count != thrustTransformMultipliers.Count) return;

            if (!tvcEnabled) return;
            if (!isOperational) return;
            if (!EngineIgnited) return;
            if (currentThrottle < 0.01f) return;

            var ctrl = vessel.ctrlState;
            ApplyDifferentialThrottle(ctrl.pitch, ctrl.yaw);
        }

        // ---- ITorqueProvider ----
        // SAS calls this to ask how much torque authority we have on each axis.
        // pos = max positive torque, neg = max negative (use absolute values; SAS expects magnitudes).
        public void GetPotentialTorque(out Vector3 pos, out Vector3 neg)
        {
            pos = neg = Vector3.zero;
            if (!tvcEnabled || !isOperational) return;

            float thrustNow = finalThrust > 0f ? finalThrust : maxThrust;
            float effectiveArm = ringRadius * (1f - minThrottleFrac) / (1f + minThrottleFrac);
            float pitchYawTorque = thrustNow * effectiveArm * tvcAuthority;

            // x = pitch, y = roll, z = yaw. Engine provides no roll authority.
            pos = new Vector3(pitchYawTorque, 0f, pitchYawTorque);
            neg = pos;
        }

        // ---- Core TVC math ----
        private void ApplyDifferentialThrottle(float pitchCmd, float yawCmd)
        {
            int n = thrustTransforms.Count;
            if (n == 0 || chamberAngles.Count != n) return;

            float baseMult = 1f / n;
            float sum = 0f;

            for (int i = 0; i < n; i++)
            {
                float theta = chamberAngles[i];
                // Pitch rotates around part's X axis; thrust shifts in Z
                // Yaw rotates around part's Z axis; thrust shifts in X
                // cos(theta) = x-component of ring position, sin(theta) = z-component
                float cmd = pitchCmd * Mathf.Sin(theta) + yawCmd * Mathf.Cos(theta);
                float m = baseMult * (1f + cmd * tvcAuthority);
                // Clamp to [minThrottleFrac/n, 2/n] so we never throttle below minimum or above double
                m = Mathf.Clamp(m, baseMult * minThrottleFrac, baseMult * 2f);
                thrustTransformMultipliers[i] = m;
                sum += m;
            }

            // Renormalize so sum = 1 (preserves total thrust regardless of TVC command)
            if (sum > 0.0001f)
            {
                float k = 1f / sum;
                for (int i = 0; i < n; i++)
                    thrustTransformMultipliers[i] *= k;
            }
        }

        private void ResetMultipliers()
        {
            int n = thrustTransforms.Count;
            if (n == 0) return;
            float share = 1f / n;
            for (int i = 0; i < n; i++)
                thrustTransformMultipliers[i] = share;
        }

        // ---- Ring construction ----
        private void BuildRing()
        {
            Transform[] originals = part.FindModelTransforms("thrustTransform");
            if (originals == null || originals.Length == 0)
            {
                Debug.LogError("[StokeEngine] No thrustTransform found on model.");
                return;
            }
            Transform original = originals[0];
            Transform anchor = original.parent;

            var toKill = new List<GameObject>();
            foreach (Transform child in anchor)
                if (child.name == CLONE_TX_NAME) toKill.Add(child.gameObject);
            foreach (var go in toKill) DestroyImmediate(go);

            int n = Mathf.Max(1, (int)chamberCount);
            chamberAngles.Clear();
            for (int i = 0; i < n; i++)
            {
                float angleDeg = 360f * i / n;
                float a = angleDeg * Mathf.Deg2Rad;
                chamberAngles.Add(a);

                GameObject clone = new GameObject(CLONE_TX_NAME);
                clone.transform.SetParent(anchor, false);
                clone.transform.localPosition = original.localPosition
                    + new Vector3(Mathf.Cos(a) * ringRadius, 0f, Mathf.Sin(a) * ringRadius);
                clone.transform.localRotation = original.localRotation;
            }

            lastBuiltCount = n;
            lastBuiltRadius = ringRadius;
        }

        private void RebindTransforms()
        {
            thrustTransforms.Clear();
            thrustTransforms.AddRange(part.FindModelTransforms(CLONE_TX_NAME));

            thrustTransformMultipliers.Clear();
            float share = 1f / Mathf.Max(1, thrustTransforms.Count);
            for (int i = 0; i < thrustTransforms.Count; i++)
                thrustTransformMultipliers.Add(share);
        }

        private void RescaleThrust()
        {
            int n = Mathf.Max(1, (int)chamberCount);
            maxThrust = thrustPerChamber * n;
            if (atmosphereCurve != null)
            {
                float vacIsp = atmosphereCurve.Evaluate(0f);
                if (vacIsp > 0.1f)
                    maxFuelFlow = maxThrust / (vacIsp * 9.80665f);
            }
            Debug.Log($"[StokeEngine] RescaleThrust: thrustPerChamber={thrustPerChamber}, " +
                      $"n={n}, maxThrust={maxThrust}, maxFuelFlow={maxFuelFlow}");
        }
    }
}